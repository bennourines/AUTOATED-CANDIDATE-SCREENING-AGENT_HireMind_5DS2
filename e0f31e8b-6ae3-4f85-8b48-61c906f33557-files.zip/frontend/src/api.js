import axios from 'axios';

const baseURL = process.env.REACT_APP_API_BASE || 'http://localhost:8000/api/v1';
export const api = axios.create({ baseURL });
